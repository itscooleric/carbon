# Selected Envoy Dispatch

This is a partial assignment package, not a Stack snapshot.
Read bootstrap.md, assignment.cast.yaml, operating-contract.md and original.handoff.md.
Retain the original complete Stack separately. Return only proposed changes.
