# Envoy Cast Return

```yaml
format: envoy.return/v0.1
assignment_id: cast-harbor-report
dispatch_id: dispatch-harbor-report
stack_id: stk-harbor-demo
base_revision: 4
checkpoint_id: checkpoint-cast-harbor-report-1
parent_checkpoint: null
status: partial
summary: Prepared proposed deliverables from supplied fictional evidence.
objective: Create a complete report from the supplied Entries.
accepted: []
evidence: []
decisions: []
completed: []
questions: []
blockers: []
next:
  - User reviews evidence and proposed changes before acceptance.
verification: []
errors: []
capabilities: []
operations_performed: []
creates: []
replaces: []
deletes: []
renames: []
boundary: harbor-return-boundary-0001
```

<!-- envoy-cast:complete boundary="harbor-return-boundary-0001" files="0" -->
